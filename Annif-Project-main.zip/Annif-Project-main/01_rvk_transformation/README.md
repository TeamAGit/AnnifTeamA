# README

* Jupyter Notebook "extract_xml_rvk.ipynb" flattens RVK Classification for Annif software.
* More information about Annif can be found here: https://github.com/NatLibFi/Annif
* RVK as XML file can be found here: https://rvk.uni-regensburg.de/regensburger-verbundklassifikation-online/rvk-download
