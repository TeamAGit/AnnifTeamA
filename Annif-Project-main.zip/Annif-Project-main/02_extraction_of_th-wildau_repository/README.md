# README

* Python script "records_extraction.py" extracts theses from the TH-Wildau repository
* It retrieves following metadata: UID, Discipline, Title, Keywords, Content, RVK(s)