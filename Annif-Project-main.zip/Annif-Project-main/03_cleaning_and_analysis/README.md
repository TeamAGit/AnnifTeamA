# README

* Jupyter Notebook "cleaning_and_analysis.ipynb" makes an analysis about the data structure and cleans the data.
* File "records_cleaned.csv" contains:
	+ Master-Theses in German only,
	+ without table of content (as of 2023-08-22),
	+ without rows containing None values,
	+ if more than one RVK, the following RVKs are deleted (as of 2023-08-22)
