After retraining tests with example text file commenced
```
annif suggest thwildau-tfidf-de <data-sets/THWildau/docs/test/4158.txt
```
![Alt](https://github.com/AndreaBrand/Annif_BIM2022/blob/main/images/test_text_file.png)

The original RVK notation was:
th-wildau:ZL3000	Allgemeine, zusammenfassende und übergreifende Darstellungen zum Maschinenbau
