# Annif_BIM2022
Documentation of first test runs with annif commenced by Team A
