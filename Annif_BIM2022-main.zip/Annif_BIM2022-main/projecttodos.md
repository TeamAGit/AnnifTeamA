Team A has to discuss folowing topics:
1. what other algorithm beside tfidf are available?
2. how to ensure that tsv, csv are error free?
3. what other analyzer are available?
4. what other methods are available to determin better raw data i. e. OCR-changes
